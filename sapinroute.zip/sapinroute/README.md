# 🎄 Mon Arbre de Noël — SapinRoute

Application de gestion de livraisons de sapins de Noël.

---

## 🚀 Déploiement sur Vercel (5 minutes)

### Étape 1 — Obtenir ta clé API Anthropic
1. Va sur **console.anthropic.com**
2. Connecte-toi ou crée un compte
3. Clique sur **"API Keys"** dans le menu
4. Clique **"Create Key"**, donne-lui un nom (ex: "SapinRoute")
5. **Copie la clé** (elle commence par `sk-ant-...`) — tu ne pourras plus la voir après !

### Étape 2 — Déployer sur Vercel
1. Va sur **vercel.com** et crée un compte gratuit
2. Sur le tableau de bord, clique **"Add New Project"**
3. Clique **"Upload"** (pas besoin de GitHub)
4. **Glisse-dépose ce dossier entier** (`sapinroute`) dans la zone
5. Vercel détecte automatiquement que c'est un projet Vite/React

### Étape 3 — Ajouter la clé API
Avant de cliquer "Deploy" :
1. Clique sur **"Environment Variables"**
2. Ajoute :
   - **Name** : `VITE_ANTHROPIC_API_KEY`
   - **Value** : ta clé `sk-ant-...`
3. Clique **"Add"**

### Étape 4 — Déployer
1. Clique **"Deploy"**
2. Attends 1-2 minutes
3. Vercel te donne une URL du type `mon-arbre-de-noel.vercel.app`

### Étape 5 — Installer sur ton iPhone
1. Ouvre l'URL dans **Safari** sur ton iPhone
2. Appuie sur l'icône **Partager** (carré avec flèche vers le haut)
3. Appuie sur **"Sur l'écran d'accueil"**
4. Appuie **"Ajouter"**
5. ✅ L'app apparaît sur ton écran comme une vraie application !

---

## 📱 Fonctionnalités

- **📋 Scanner** — Prends en photo un bon de livraison, l'IA extrait tout automatiquement
- **🗓 Agenda** — Calendrier avec tous tes jours de livraison, triés par créneau horaire
- **🗺️ Carte** — Visualise tes livraisons du jour, itinéraire optimisé par IA, boutons Waze et Google Maps
- **📚 Historique** — Tous tes jours passés, consultables et exportables
- **📊 Saison** — Récapitulatif annuel, stats par taille/type, export CSV "Saison 2025"
- **✏️ Modifier** — Modifie date, créneau, coordonnées à tout moment
- **🌙 Auto-archivage** — Les livraisons terminées s'archivent automatiquement chaque nuit

---

## 💰 Coût

- **Vercel** : gratuit
- **API Anthropic** : environ 0,002€ par scan de bon (très peu coûteux)

---

## 🛠 Développement local (optionnel)

```bash
# Installer les dépendances
npm install

# Créer le fichier .env
cp .env.example .env
# Edite .env et mets ta vraie clé API

# Lancer en local
npm run dev
```
